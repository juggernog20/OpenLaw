Fictional bundle.
